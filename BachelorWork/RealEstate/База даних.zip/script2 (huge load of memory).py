import psycopg2
print("Reading of file...",end="")
SourceFile=open("houses.csv",'r')
SourceFile.readline()
data={}
for line in SourceFile:
	line
	i=0
	while(line[i]!=';'):
		i+=1
	district=line[:i]
	i+=1
	PrevI=i	
	while(line[i]!=';'):
		i+=1
	town=line[PrevI:i]
	if(town!="м. Київ"):
		continue
	i+=1
	PrevI=i	
	while(line[i]!=';'):
		i+=1
	street=line[PrevI:i]
	i+=1	
	if(district not in data):
		data[district]={}
	if(town not in data[district]):
		data[district][town]={}
	if(street not in data[district][town]):
		data[district][town][street]=[]
		# StreetQuery="INSERT INTO Вулиці(\"Область\",\"Населений пункт\",\"Назва вулиці\") Values (\'"+district+"\'"+",\'"+town+"\'"+",\'"+street+"\');"
	# BuildingQuery="INSERT INTO Будинки(\"Область\",\"Населений пункт\",\"Вулиця\",\"№ будинку\") Values "
	LineLength=len(line)
	while(i<LineLength):
		PrevI=i
		while(line[i].isalpha() or line[i].isdigit()):
			i+=1
		building=line[PrevI:i]
		if(building not in data[district][town][street]):
			data[district][town][street].append(building)
			# BuildingQuery+="(\'"+district+"\'"+",\'"+town+"\'"+",\'"+street+"\',\'"+building+"\'),"
		i+=1
		while(i<LineLength and line[i].isalpha()==False and line[i].isdigit()==False):
			i+=1
	# BuildingQuery=BuildingQuery[0:len(BuildingQuery)-1]+';'
SourceFile.close()
print(" Building of queries...",end="")
DistrictQueryFile=open("DistrictQuery.txt",'w')
TownQueryFile=open("TownQuery.txt",'w')
StreetQueryFile=open("StreetQuery.txt",'w')
BuildingQueryFile=open("BuildingQuery.txt",'w')
DistrictQueryFile.write("INSERT INTO Області(\"Назва області\") Values ")
TownQueryFile.write("INSERT INTO \"Населені пункти\"(\"Область\",\"Назва населеного пункту\") Values ")
StreetQueryFile.write("INSERT INTO Вулиці(\"Область\",\"Населений пункт\",\"Назва вулиці\") Values ")
BuildingQueryFile.write("INSERT INTO Будинки(\"Область\",\"Населений пункт\",\"Вулиця\",\"№ будинку\") Values ")
for district in data:
	DistrictQueryFile.write("(\'"+district+"\'),")
	for town in data[district]:
		TownQueryFile.write("(\'"+district+"\'"+",\'"+town+"\'),")
		for street in data[district][town]:
			StreetQueryFile.write("(\'"+district+"\'"+",\'"+town+"\'"+",\'"+street+"\'),")
			for building in data[district][town][street]:
				BuildingQueryFile.write("(\'"+district+"\'"+",\'"+town+"\'"+",\'"+street+"\',\'"+building+"\'),")
DistrictQueryFile.close()
TownQueryFile.close()
StreetQueryFile.close()
BuildingQueryFile.close()
DistrictQueryFile=open("DistrictQuery.txt",'r')
TownQueryFile=open("TownQuery.txt",'r')
StreetQueryFile=open("StreetQuery.txt",'r')
BuildingQueryFile=open("BuildingQuery.txt",'r')
DistrictQuery=DistrictQueryFile.readline()
TownQuery=TownQueryFile.readline()
StreetQuery=StreetQueryFile.readline()
BuildingQuery=BuildingQueryFile.readline()
DistrictQueryFile.close()
TownQueryFile.close()
StreetQueryFile.close()
BuildingQueryFile.close()
DistrictQuery=DistrictQuery[0:len(DistrictQuery)-1]+';'
TownQuery=TownQuery[0:len(TownQuery)-1]+';'
StreetQuery=StreetQuery[0:len(StreetQuery)-1]+';'
BuildingQuery=BuildingQuery[0:len(BuildingQuery)-1]+';'
print(" Execution of queries...",end="")
connection = psycopg2.connect(database="realestate",user="sqluser",password="5353A201",host="127.0.0.1",port="5432")
cursor=connection.cursor()
cursor.execute(DistrictQuery)
connection.commit()
cursor.execute(TownQuery)
connection.commit()
cursor.execute(StreetQuery)
connection.commit()
cursor.execute(BuildingQuery)
connection.commit()
print("\n")